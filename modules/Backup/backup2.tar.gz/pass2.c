#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "assembly.h"

#define SINGLEQUOTE 0x27	//The symbol '
#define MAXTRLEN	90	//Max text record length in bytes

extern SIC_prog_info program_info;

//Generate address portion of an object by finding operands address from symtab. Also check that address does not croos the limit LAST_PROG_ADDR.
#define generate_objcode_addr()		uint16_t temp;	\
					sscanf(get_symbol_addr(intr_line.instr->operand),"%X",&temp);	\
					if(temp >= LAST_PROG_ADDR){	\
						fprintf(stderr,"Error: Program size too large\n");	\
							exit(1);	\
					}	\
					hex_addr = temp;

/*	Pass-2 assembly algorithm	*/
void pass2() {
	FILE *intr_file, *listing, *obj_prog, *src_file;
	char symval[10]="", obj_code[10]="";
	char *objprog_name, text_rec[MAXTRLEN]="";	//81bytes is enough to hold a text record. 
	int txtrec_ctr; //Text record counter
	
	SIC_addr hex_addr;	//program length is just taken as fixed for now.
	SIC_reg index = 0x08;	//X = 0000 1000(Just taken)
	SIC_int_instr intr_line;	//Lines read from intermediate file
	SIC_list_instr list_line;	//Lines written to listing file

	int reswb_f = 0;	//RESW or RESB found flag. A special flag used during object program production by pass2 only
	
#define hex_addr	(hex_addr.val)

	//Input source file
	if((src_file = fopen(program_info.prog_name,"r")) == NULL){
		fprintf(stderr,"\nError: Could not open source file\n");
		exit(1);
	}
	if((intr_file = fopen(".intermediate","r")) == NULL){
		fprintf(stderr,"\nError: Could not load intermediate file\n");
		exit(1);
	}
	if((listing = fopen(".listing","w")) == NULL){	//Assembly listing file
		fprintf(stderr,"Error: Cannot open listing file\n");
		exit(1);
	}
	
	objprog_name = (char*)calloc(strlen(program_info.prog_name)+5,sizeof(char));
	strcpy(objprog_name,program_info.prog_name);
	strcat(objprog_name,".o");
	//Object program file
	if((obj_prog = fopen(objprog_name,"w")) == NULL){
		fprintf(stderr,"\nError: Could not open object file\n");
		exit(1);
	}
	//reset_flags();	//Reset all flags
	
	//Read first line of intermediate file
	read_line_intr(intr_file, &intr_line);
	
	//First startement of the source program
	if(strcmp(intr_line.instr->opcode,"START")==0){
		write_line_list(listing, &list_line);

		//Write object program header record
		fprintf(obj_prog, "H^%-6s^%06X^%06X\n", program_info.prog_name, program_info.start_addr, program_info.prog_len);

		read_line_intr(intr_file, &intr_line);
	}
	
	//Initialize first text record
	fprintf(obj_prog,"T^%06X^",intr_line.addr.val);

	//Scan intermediate file till 'END' statement or End of file(EOF)
	while((strcmp(intr_line.instr->opcode,"END")!=0) && !feof(intr_file)){
		//If comment line
		if(strcmp(intr_line.instr->label,".") == 0){
			read_line_intr(intr_file, &intr_line);
			continue;
		}
		//Else parse line....
		if(search_optab(intr_line.instr->opcode) == FOUND){	//Opcode found
			if(strcmp(intr_line.instr->operand,"-") != 0){//Not an empty label field
				if(search_symtab(intr_line.instr->operand) == FOUND){//Symbol found
					generate_objcode_addr();
				}
				else if(strstr(intr_line.instr->operand,",X") != (char*)0){	//For indexed addressing, add value of X to address
					char temp_sym[10]="";
					//uint16_t temp;
					SIC_addr temp_addr;
					//Extract the symbol(excluding ',X') from the operand field
					strncpy(temp_sym,intr_line.instr->operand,strcspn(intr_line.instr->operand,",X"));
					if(search_symtab(temp_sym) == NOTFOUND){
						fprintf(stderr,"Error: Invalid symbol found\n");
						exit(1);
					}
					generate_objcode_addr();
					//sscanf(get_symbol_addr(temp_sym),"%X",&temp);
					hex_addr += index;	//Add hex_addr+index_register. Computed as integers
				}
				else{	//Invalid symbol
					hex_addr = 0;
					//@ERR: sym_f = 1;	//Invalid symbol flag
				}
			}//operand "-"
			else
				hex_addr = 0;
				//@strcpy(symval,"0000");
				//sscanf("0","%X",&hex_addr);
			
			//Make the complete object code
			sprintf(symval,"%04X",hex_addr);
			//printf("symval: %s\thex_addr: %d\n",symval,hex_addr);
			strcpy(obj_code,get_hexcode(intr_line.instr->opcode));	// 04
			//@strcat(obj_code,symval);
			strcat(obj_code,symval);	//04400C
			
		}//end if opcode found
		else if(strcmp(intr_line.instr->opcode,"WORD")==0){
			//uint16_t temp;
			//sscanf(intr_line.instr->operand,"%X",&temp);
			hex_addr = intr_line.addr.val;
			sprintf(obj_code,"%06X",hex_addr);
		}
		else if(strcmp(intr_line.instr->opcode,"BYTE")==0){
			char temp[10]="";	//Temp constant value variable
			if(intr_line.instr->operand[0] == 'C'){	//Eg: C'EOF'
				char *ptr;
				ptr = strstr(intr_line.instr->operand,"'") + 1;
				if(strcmp(ptr,"EOF'") == 0)
					strcpy(temp,"454F46");
				//Any other character constants can be added here.....TODO
				else{
					fprintf(stderr,"\nError: Invalid constand type\tAt label: %s\n",intr_line.instr->label);
					exit(1);
				}
			}
			else if(intr_line.instr->operand[0] == 'X'){	//Eg: X'F1'
				char *ptr;
				short int i=0;
				ptr = strstr(intr_line.instr->operand,"'") + 1;
				while(*ptr != SINGLEQUOTE){
					temp[i] = *ptr;
					ptr++; i++;
				}
			}
			sscanf(temp,"%06X",&symval);
			strcpy(obj_code, symval);
		}
		//For RESW and RESB
		else if((strcmp(intr_line.instr->opcode,"RESW")==0) || (strcmp(intr_line.instr->opcode,"RESB")==0)){
			strcpy(obj_code,"");
			//@txtrec_end_f = 1;	
		}
		//else neither an opcode nor a directive
		
		//Text record production begins here...
		if((txtrec_ctr < MAXTRLEN) && (strcmp(intr_line.instr->opcode,"RESW") && strcmp(intr_line.instr->opcode,"RESB"))){
			if(reswb_f){	//if RESW or RESB was last found then new text record should begin
				fprintf(obj_prog,"%02X",txtrec_ctr);
				fprintf(obj_prog,"%s\n",text_rec);
				//Reset text_rec string
				strcpy(text_rec,"");
				txtrec_ctr = 0x0;
				//uint16_t temp;
				//sscanf(intr_line.addr,"%X",&temp);
				//hex_addr = temp;
				fprintf(obj_prog,"T^%06X^",intr_line.addr);
				reswb_f = 0;
			}

			//Add obj_code to current text record.(Be careful from adding a '^' with a NULL obj_code)
			if(strcmp(obj_code,"") != 0){
				strcat(text_rec,"^");
				strcat(text_rec,obj_code);
				txtrec_ctr += 0x03;			// (+ 03H) default for simple SIC
			}
		}

		else if(!strcmp(intr_line.instr->opcode,"RESW") || !strcmp(intr_line.instr->opcode,"RESB"))
			reswb_f = 1;	//RESW,RESB was found flag

		else{	//no more place in the current text record.Create a new one
			//Time to flush the generated text_rec string and prepare for a new text record, if any
			//Insert the 'length' and 'object codes' fields of the currently ending text record
			fprintf(obj_prog,"%02X",txtrec_ctr);
			fprintf(obj_prog,"%s\n",text_rec);
			//Reset text_rec string
			strcpy(text_rec,"");
			txtrec_ctr = 0x0;
			//uint16_t temp;
			//sscanf(intr_line.addr,"%X",&temp);
			hex_addr = intr_line.addr.val;
			fprintf(obj_prog,"T^%06X^",hex_addr);
			if(strcmp(obj_code,"") != 0){
				strcat(text_rec,"^");
				strcat(text_rec,obj_code);
				txtrec_ctr += 0x03;
			}
			//------------- OLD CODE --------------------
			//@int n = strlen(text_rec);
			//@@char *temp_txtrec_r,temp_txtrec_l[100]="",temp_ctr[5]="";	//=(char*)calloc(50,sizeof(char));
			//@text_rec[n-1] = '\0';	//Remove the extra '^' character that is generated 
			//@printf("%s\n", text_rec);
			
			//@insert_txtlen(text_rec,txtrec_ctr);
			//@@strncpy(temp_txtrec_l, text_rec, strcspn(text_rec,"-"));	//Left half
			//@@printf("%s\n", temp_txtrec_l);
			//@@temp_txtrec_r = strstr(text_rec, "-") + 1;	//Right half
			//@@printf("%s\n", temp_txtrec_r);

			//@@sprintf(temp_ctr, "%02d",txtrec_ctr);
			//@@printf("%s\n", temp_ctr);
			//@@strcat(temp_txtrec_l, temp_ctr);
			//@@printf("%s\n", temp_txtrec_l);
			//@@strcat(temp_txtrec_l, temp_txtrec_r);
			//@@printf("%s\n", temp_txtrec_l);
			//@strcpy(text_rec, "");
			//@@strcpy(text_rec, temp_txtrec_l);
			//@@printf("%s\n", text_rec);
			
		}
			
		//Write to assembly listing file
		write_line_list(listing, &list_line);
		
		//Read next line
		read_line_intr(intr_file, &intr_line);
		
	}//while(END)
	
	//Insert the left over text record, if any
	if(strcmp(text_rec,"") != 0){
		//Insert the 'length' and 'object codes' fields of the currently ending text record
		fprintf(obj_prog,"%02X",txtrec_ctr);
		fprintf(obj_prog,"%s\n",text_rec);
	}
	//Write last line to assembly listing file	
	write_line_list(listing, &list_line);
	
	//Write the END record
	fprintf(obj_prog,"E^%06X", program_info.start_addr);

	//Close all files
	fclose(listing);
	fclose(intr_file);
	fclose(obj_prog);
}
