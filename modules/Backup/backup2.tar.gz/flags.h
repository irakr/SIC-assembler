/*
 *	flags.h
 *
 *	This file contains all the flag variables required for the execution of the assembler.
 */

//Error flag
