/*
 *	main.c
 *
 *	This is the main program for the SIC assembler module.
 */
#include <pass1.h>
#include <pass2.h>

